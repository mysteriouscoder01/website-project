
import os, json
import requests
from flask import Flask, render_template, jsonify, request

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static"),
)

# ------------------ VERİLER ------------------
TIPS = [
    {"id":1,"emoji":"🌳","baslik":"Ağaç dik ve yeşil alanları koru","kategori":"Bireysel","etki":"Yüksek",
     "neden":"Ağaçlar CO₂’yi emer, ısı adası etkisini azaltır, sel ve erozyonu önler.",
     "nasil":"Fidan dikimlerine katıl; yerel türleri dik; kesimlere itiraz et."},
    {"id":2,"emoji":"🚲","baslik":"Toplu taşıma veya bisiklet kullan","kategori":"Ulaşım","etki":"Yüksek",
     "neden":"Kişi başına emisyon özel araca göre çok daha düşüktür.",
     "nasil":"Kısa mesafede bisiklet/yürü; işe metro/otobüs; haftada 1 gün arabasız."},
    {"id":3,"emoji":"💡","baslik":"Enerji verimliliği uygula","kategori":"Ev","etki":"Orta",
     "neden":"Talep düşer, fosil kaynaklı elektrik ihtiyacı azalır.",
     "nasil":"LED lamba, bekleme yerine tamamen kapat, akıllı priz kullan."},
    {"id":4,"emoji":"🔄","baslik":"Geri dönüşüm yap","kategori":"Atık","etki":"Orta",
     "neden":"Ham madde/enerji ihtiyacı düşer; depolamada metan salınımı azalır.",
     "nasil":"Kâğıt, cam, metal, plastik ve e-atıkları ayrı topla."},
    {"id":5,"emoji":"🥦","baslik":"Bitkisel ağırlıklı beslen","kategori":"Beslenme","etki":"Yüksek",
     "neden":"Kırmızı et üretimi arazi, su ve metan emisyonunda yüksektir.",
     "nasil":"Haftada 2–3 gün etsiz menü; yerel, mevsiminde ürünler."},
    {"id":6,"emoji":"🧊","baslik":"Isı yalıtımı & verimli cihazlar","kategori":"Ev","etki":"Yüksek",
     "neden":"Isıtma/soğutma evsel enerjinin büyük kısmıdır.",
     "nasil":"Pencere/kapı fitili; çatı/duvar yalıtımı; A+++ cihazlar."},
    {"id":7,"emoji":"🛍️","baslik":"Az ambalajlı ve yeniden kullanılabilir ürünler","kategori":"Atık","etki":"Orta",
     "neden":"Tek kullanımlık plastik üretimi ve yakımı emisyon yaratır.",
     "nasil":"Bez çanta, matara; cam/karton tercih et; büyük boy paket al."},
    {"id":8,"emoji":"✈️","baslik":"Kısa uçuş yerine tren/otobüs","kategori":"Ulaşım","etki":"Yüksek",
     "neden":"Kısa uçuşlar yolcu-km başına en yüksek emisyona sahip.",
     "nasil":"<700 km yolculuklarda demiryolu ve otobüsü önceliklendir."},
    {"id":9,"emoji":"♻️","baslik":"Paylaş, onar, ikinci el değerlendir","kategori":"Tüketim","etki":"Orta",
     "neden":"Yeni ürün üretimi enerji ve hammadde yoğun bir süreçtir.",
     "nasil":"Onarım atölyeleri; takas; daha az ama kaliteli ürün."},
    {"id":10,"emoji":"🌞","baslik":"Yenilenebilir enerjiye geç","kategori":"Enerji","etki":"Yüksek",
     "neden":"Elektrikte fosil payını azaltır.",
     "nasil":"Yeşil tarife/enerji kooperatifi; mümkünse çatı GES aboneliği."},
    {"id":11,"emoji":"📣","baslik":"Toplulukla politika/altyapı için çalış","kategori":"Topluluk","etki":"Yapısal",
     "neden":"Yapısal değişimler bireysel etkileri katlar.",
     "nasil":"Belediye iklim eylem planı, imza kampanyası, gönüllülük."}
]

ARTICLES_PATH = os.path.join(BASE_DIR, "data", "articles.json")

def load_articles():
    try:
        with open(ARTICLES_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

# ------------------ SAYFALAR ------------------
@app.route("/")
def home():
    return render_template("index.html", articles=load_articles())

@app.route("/makale/<slug>")
def article(slug):
    art = next((a for a in load_articles() if a.get("slug") == slug), None)
    if not art:
        art = {"baslik":"Bulunamadı","icerik":["İstenen makale yok."]}
    return render_template("article.html", article=art)

# ------------------ API ------------------
@app.route("/api/tips")
def api_tips():
    q = (request.args.get("q") or "").lower().strip()
    kategori = (request.args.get("kategori") or "").strip()
    data = TIPS

    if q:
        data = [t for t in data
                if q in t["baslik"].lower()
                or q in t["neden"].lower()
                or q in t["nasil"].lower()]

    if kategori:
        data = [t for t in data if t["kategori"].lower() == kategori.lower()]

    return jsonify(data)

@app.route("/api/footprint", methods=["POST"])
def api_footprint():
    p = request.get_json(force=True)
    araba_km = float(p.get("araba_km", 0))
    elektrik_kwh = float(p.get("elektrik_kwh", 0))
    dogalgaz_m3 = float(p.get("dogalgaz_m3", 0))
    uckisa = int(p.get("uckisasefer", 0))
    kirmizi_et_gun = int(p.get("kirmizi_et_gun", 0))

    EF_ARABA = 0.18       # kg CO2e / km
    EF_ELEK  = 0.45       # kg CO2e / kWh
    EF_GAZ   = 1.9        # kg CO2e / m3
    EF_UCUS_KISA = 150.0  # kg CO2e / uçuş
    EF_ET_GUN    = 3.0    # kg CO2e / gün (haftalık * 52)

    yillik = (
        araba_km*EF_ARABA +
        elektrik_kwh*EF_ELEK +
        dogalgaz_m3*EF_GAZ +
        uckisa*EF_UCUS_KISA +
        (kirmizi_et_gun*EF_ET_GUN*52)
    )

    if yillik < 3000: seviye = "Düşük"
    elif yillik < 7000: seviye = "Orta"
    else: seviye = "Yüksek"

    return jsonify({"yillik_kgco2e": round(yillik), "seviye": seviye})

@app.route("/weather/<city>")
def weather(city):
    api_key = os.environ.get("OPENWEATHER_API_KEY", "")
    if not api_key:
        return jsonify({"error":"OPENWEATHER_API_KEY tanımlı değil"}), 400
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric&lang=tr"
    try:
        r = requests.get(url, timeout=10)
        data = r.json()
        if r.status_code != 200 or data.get("cod") != 200:
            return jsonify({"error": data.get("message","Hata")}), 400
        return jsonify({
            "sehir": city,
            "sicaklik": data["main"]["temp"],
            "aciklama": data["weather"][0]["description"]
        })
    except Exception:
        return jsonify({"error": "Bağlantı hatası"}), 500

if __name__ == "__main__":
    app.run(debug=True)
