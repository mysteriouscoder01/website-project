// ÖNERİLER
const listEl = document.getElementById('tipList');
const searchEl = document.getElementById('search');
const kategoriEl = document.getElementById('kategori');
const filtreBtn = document.getElementById('filtrele');
const dahaFazlaBtn = document.getElementById('dahaFazla');
const dahaAzBtn = document.getElementById('dahaAz');

let allTips = [];
let visibleCount = 6;

async function loadTips(){
  const params = new URLSearchParams();
  const q = (searchEl?.value || '').trim();
  const k = (kategoriEl?.value || '').trim();
  if(q) params.set('q', q);
  if(k) params.set('kategori', k);
  const res = await fetch(`/api/tips?${params.toString()}`);
  allTips = await res.json();
  visibleCount = 6;
  render();
}

function render(){
  if(!listEl) return;
  listEl.innerHTML = '';
  const items = allTips.slice(0, visibleCount);
  items.forEach(t => {
    const el = document.createElement('article');
    el.className = 'card';
    el.innerHTML = `
      <div class="card-header">
        <div class="card-emoji">${t.emoji}</div>
        <h3 class="card-title">${t.baslik}<span class="tag">${t.kategori}</span></h3>
      </div>
      <div class="meta">Etki: <b>${t.etki}</b></div>
      <details class="details"><summary>▶ Neden etkili?</summary><p style="margin:8px 0 0">${t.neden}</p></details>
      <details class="details"><summary>▶ Nasıl uygularım?</summary><p style="margin:8px 0 0">${t.nasil}</p></details>
    `;
    listEl.appendChild(el);
  });
  if(dahaFazlaBtn) dahaFazlaBtn.style.display = visibleCount < allTips.length ? 'inline-block' : 'none';
  if(dahaAzBtn) dahaAzBtn.style.display = visibleCount > 6 ? 'inline-block' : 'none';
}

filtreBtn?.addEventListener('click', loadTips);
searchEl?.addEventListener('keydown', e => { if(e.key==='Enter') loadTips(); });
kategoriEl?.addEventListener('change', loadTips);
dahaFazlaBtn?.addEventListener('click', () => { visibleCount = Math.min(visibleCount + 6, allTips.length); render(); });
dahaAzBtn?.addEventListener('click', () => { visibleCount = 6; render(); });

// HAVA DURUMU
const havaBtn = document.getElementById('havaGetir');
havaBtn?.addEventListener('click', async () => {
  const city = document.getElementById('city').value.trim();
  const out = document.getElementById('havaSonuc');
  if(!city){ out.textContent = 'Şehir girin.'; return; }
  try {
    const res = await fetch(`/weather/${encodeURIComponent(city)}`);
    const data = await res.json();
    out.textContent = data.error ? `Hata: ${data.error}` : `${data.sehir}: ${data.sicaklik.toFixed(0)}°C – ${data.aciklama}`;
  } catch { out.textContent = 'Bağlantı hatası.'; }
});

// KARBON AYAK İZİ
const fpForm = document.getElementById('footprintForm');
fpForm?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(fpForm);
  const body = Object.fromEntries(fd.entries());
  Object.keys(body).forEach(k => body[k] = body[k] === '' ? 0 : body[k]);
  const res = await fetch('/api/footprint', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
  const data = await res.json();
  const out = document.getElementById('fpSonuc');
  out.textContent = (data.yillik_kgco2e !== undefined)
    ? `Yıllık tahmini: ${data.yillik_kgco2e} kg CO₂e – Seviye: ${data.seviye}`
    : 'Hesaplama yapılamadı.';
});

// ilk yükleme
loadTips();
